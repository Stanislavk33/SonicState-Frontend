import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

export class AudioDetails {
  public name: string;
  public bpm: number;
  public key: string;
}

@Injectable({
  providedIn: 'root'
})
export class HttpProxy {
  constructor(private http: HttpClient) { }

  public get<T>(url: string): Observable<T> {
    const headers = this.defaultHeaders();
    return this.http.get<T>(url, { headers });
  }

  public post<T>(url: string, data: any): Observable<T> {
    const headers = this.defaultHeaders();
    return this.http.post<T>(url, data, { headers });
  }

  private defaultHeaders(): HttpHeaders {
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');

    return headers;
  }
}

@Injectable({
  providedIn: 'root'
})
export class AudioService {
  private baseUrl:  string = environment.url;

  constructor(private http: HttpProxy) { }

  public getAll(): Observable<AudioDetails[]>{
      return this.http.get<AudioDetails[]>(this.baseUrl + 'audio/list');
  }

  public upload(data: any) {
    return this.http.post(this.baseUrl + 'audio/list', data);
  }
}
