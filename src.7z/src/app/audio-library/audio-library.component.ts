import { Component, OnInit } from '@angular/core';
import { AudioService, AudioDetails } from 'src/services/audio.service';

@Component({
  selector: 'app-audio-library',
  templateUrl: './audio-library.component.html',
  styleUrls: ['./audio-library.component.css']
})
export class AudioLibraryComponent implements OnInit {

  public audios: AudioDetails[];
  constructor(private service: AudioService) { }

  ngOnInit() {
    this.service.getAll().subscribe(audioDetails => {
      this.audios = audioDetails;
      debugger;
    });
  }

  public showDetails(key: string) {
    var uploadModel = {
      gosho: 1,
      neshtoSAi: 2
    };

    this.service.upload(uploadModel).subscribe(isFinished => {
      debugger;
    });
  }

}
